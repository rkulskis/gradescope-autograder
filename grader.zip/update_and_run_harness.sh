#! /usr/bin/env bash

/autograder/update_harness.py
chmod +x /autograder/harness.py

/autograder/harness.py
